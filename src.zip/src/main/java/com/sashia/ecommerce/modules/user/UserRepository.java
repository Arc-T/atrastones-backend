package com.sashia.ecommerce.modules.user;

import com.sashia.ecommerce.modules.order.Order;
import com.sashia.ecommerce.modules.user.address.Address;
import com.sashia.ecommerce.modules.user.vip.VipGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface UserRepository {

    // -------------------------------- CREATE --------------------------------

    Long create(UserDTO user);

    // -------------------------------- UPDATE --------------------------------

    void update(Long id, UserDTO user);

    // -------------------------------- SELECT --------------------------------

    Page<User> getAll(Pageable pageable);

    List<Order> getUserOrders(Long userId);

    List<VipGroup> getUserVipGroups(Long userId);

    List<Address> getUserAddresses(Long userId);

    // -------------------------------- OPERATIONS --------------------------------

    boolean exists(Long id);

    boolean existByPhone(String phone);

}
