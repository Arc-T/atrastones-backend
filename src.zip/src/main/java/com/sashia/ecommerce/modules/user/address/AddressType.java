package com.sashia.ecommerce.modules.user.address;

public enum AddressType {
    HOME, WORK, OTHER
}