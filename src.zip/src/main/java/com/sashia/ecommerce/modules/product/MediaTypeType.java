package com.sashia.ecommerce.modules.product;

public enum MediaTypeType {
    IMAGE, VIDEO, AUDIO
}
