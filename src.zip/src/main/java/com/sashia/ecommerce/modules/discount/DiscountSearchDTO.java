package com.sashia.ecommerce.modules.discount;

public record DiscountSearchDTO() {
}
