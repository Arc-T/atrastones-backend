package com.sashia.ecommerce.modules.notification.sms;

import com.sashia.ecommerce.modules.notification.common.SMSEventDTO;
import com.sashia.ecommerce.modules.notification.sms.common.SMSProvider;

public interface SMSContract {

    SMSProvider getProvider();

    void send(SMSEventDTO event);

}
