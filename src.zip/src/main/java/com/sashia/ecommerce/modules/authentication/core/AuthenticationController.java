package com.sashia.ecommerce.modules.authentication.core;

import com.sashia.ecommerce.modules.authentication.common.AuthenticationDTO;
import com.sashia.ecommerce.modules.authentication.common.LoginDTO;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/authentication")
class AuthenticationController {

    private final AuthenticationService authenticationService;

    AuthenticationController(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    @PostMapping
    ResponseEntity<AuthenticationDTO> login(HttpServletResponse response,
                                            @RequestBody @Valid LoginDTO credentials) {
        AuthenticationDTO authUser = authenticationService.authenticateAdmin(credentials);
        response.addHeader("Set-Cookie",
                ResponseCookie.from("token", authUser.token())
                        .httpOnly(true)
//                        .secure(true)
                        .path("/")
                        .maxAge(70 * 24 * 60 * 600)
//                        .sameSite("None")
                        .build()
                        .toString()
        );
        return ResponseEntity.ok().build();
    }

    @PostMapping("/logout")
    @PreAuthorize("hasRole('SHOP_OWNER')")
    ResponseEntity<?> logout(HttpServletResponse response) {
        Cookie refreshCookie = new Cookie("token", null);
        refreshCookie.setHttpOnly(true);
        refreshCookie.setSecure(true);
        refreshCookie.setPath("/");
        refreshCookie.setMaxAge(0);
        refreshCookie.setAttribute("SameSite", "Strict");
        response.addCookie(refreshCookie);

        return ResponseEntity.ok().build();
    }

    @PostMapping("/validate")
    @PreAuthorize("hasRole('SHOP_OWNER')")
    ResponseEntity<Boolean> validate() {
        return ResponseEntity.ok(true);
    }

//    @PostMapping("/otp")
//     ResponseEntity<Boolean> login(@RequestBody AuthenticationDTO authentication) {
//        return ResponseEntity.ok(authenticationServiceContract.authenticateUser(authentication));
//    }
//
//    @PostMapping("/email")
//     ResponseEntity<Boolean> login(@RequestBody AuthenticationDTO authentication) {
//        return ResponseEntity.ok(authenticationServiceContract.authenticateUser(authentication));
//    }
//
//    @PostMapping("/password")
//     ResponseEntity<Boolean> login(@RequestBody AuthenticationDTO authentication) {
//        return ResponseEntity.ok(authenticationServiceContract.authenticateUser(authentication));
//    }

}
