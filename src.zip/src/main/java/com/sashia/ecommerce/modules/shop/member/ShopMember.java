package com.sashia.ecommerce.modules.shop.member;

public class ShopMember {
}
