package com.sashia.ecommerce.modules.attribute;

import org.jspecify.annotations.Nullable;

public record AttributeSearchDTO(
        @Nullable
        String name
) {
}