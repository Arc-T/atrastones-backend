package com.sashia.ecommerce.modules.service.group.common;

import org.jspecify.annotations.Nullable;

public record ServiceGroupSearchDTO(
        @Nullable String name
) {
}
