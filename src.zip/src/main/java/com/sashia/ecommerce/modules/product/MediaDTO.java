package com.sashia.ecommerce.modules.product;

public record MediaDTO(String url, String extension) {

    public MediaDTO(String url) {
        this(url, null);
    }

}