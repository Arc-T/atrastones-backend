package com.sashia.ecommerce.modules.discount;

import com.sashia.ecommerce.modules.discount.common.DiscountCreateDTO;
import com.sashia.ecommerce.modules.discount.common.DiscountDTO;
import com.sashia.ecommerce.modules.discount.common.DiscountEditDTO;
import com.sashia.ecommerce.modules.product.ProductPriceDTO;
import com.sashia.ecommerce.modules.product.common.ProductDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface DiscountService {

    /* ============================= CREATE ============================= */

    Long save(DiscountCreateDTO discount);

    /* ============================= READ ============================= */

    DiscountDTO get(Long id);

    Page<DiscountDTO> getAll(Pageable pageable, DiscountSearchDTO search);

    Optional<DiscountDTO> getActiveDiscount();

    /* ============================= UPDATE ============================= */

    void update(Long id, DiscountEditDTO discountEdit);

    /* ============================= DELETE ============================= */

    void delete(Long id);

    /* ============================= OPERATIONS ============================= */

    List<ProductPriceDTO> applyDiscountToProducts(DiscountDTO discount, List<ProductDTO> product);

}