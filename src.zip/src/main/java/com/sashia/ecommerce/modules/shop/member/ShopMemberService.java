package com.sashia.ecommerce.modules.shop.member;

public interface ShopMemberService {
}
