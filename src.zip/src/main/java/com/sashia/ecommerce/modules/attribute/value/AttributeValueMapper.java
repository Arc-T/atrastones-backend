package com.sashia.ecommerce.modules.attribute.value;

import com.sashia.ecommerce.modules.attribute.Attribute;

public class AttributeValueMapper {

    private AttributeValueMapper() {
    }

    public static AttributeValueDTO toDTO(AttributeValue attributeValue) {
        return new AttributeValueDTO(
                attributeValue.getId(),
                attributeValue.getAttributeValue(),
                attributeValue.getCreatedAt()
        );
    }

    public static AttributeValue toEntity(AttributeValueDTO dto, Attribute attribute) {
        AttributeValue attributeValue = new AttributeValue();
        attributeValue.setAttribute(attribute);
        attributeValue.setAttributeValue(dto.value());
        return attributeValue;
    }

}
