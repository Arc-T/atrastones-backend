package com.sashia.ecommerce.modules.attribute;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface AttributeService {

    /* ============================= CREATE ============================= */

    Long create(AttributeCreateDTO attribute);

    /* ============================= READ ============================= */

    Optional<AttributeDTO> read(Long id);

    Page<AttributeDTO> readAll(Pageable pageable, AttributeSearchDTO search);

    /* ============================= UPDATE ============================= */

    void update(Long id, AttributeUpdateDTO attribute);

    /* ============================= DELETE ============================= */

    void delete(Long id);

    /* ============================ OPERATIONS ============================ */

    boolean exists(Long id);

}