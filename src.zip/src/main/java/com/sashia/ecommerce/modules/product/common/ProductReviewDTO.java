package com.sashia.ecommerce.modules.product.common;

public record ProductReviewDTO() {
}
