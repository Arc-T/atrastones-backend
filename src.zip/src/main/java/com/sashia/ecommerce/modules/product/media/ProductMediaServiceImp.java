package com.sashia.ecommerce.modules.product.media;

import com.sashia.ecommerce.modules.product.MediaDTO;
import com.sashia.ecommerce.modules.product.ProductMediaDTO;
import com.sashia.ecommerce.modules.product.ProductRepository;
import com.sashia.ecommerce.common.exception.InvalidResourceException;
import com.sashia.ecommerce.modules.product.media.utils.MediaUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductMediaServiceImp implements ProductMediaService {

    private final ProductRepository productRepository;
    private final ProductMediaRepository productMediaRepository;

    public ProductMediaServiceImp(ProductRepository productRepository, ProductMediaRepository productMediaRepository) {
        this.productRepository = productRepository;
        this.productMediaRepository = productMediaRepository;
    }

    @Override
    @Transactional
    public List<Long> save(Long productId) {
        return productMediaRepository.createBatch(
                MediaUtils.moveAllDraftsToProduct(productId, false)
        );
    }

    @Override
    @Transactional
    public void update(Long productId) {
        productMediaRepository.createBatch(
                MediaUtils.moveAllDraftsToProduct(productId, true)
        );
    }

    @Override
    @Transactional
    public void delete(Long id) {
        ProductMediaDTO productMedia = productMediaRepository.get(id)
                .map(ProductMediaDTO::toDTO)
                .orElseThrow(() -> new InvalidResourceException("INVALID.PRODUCT_MEDIA.ID"));

        if (productMediaRepository.delete(productMedia.id()))
            MediaUtils.deleteProductMedia(productMedia.productId(), productMedia.url());
        else
            throw new InvalidResourceException("SYSTEM_ERROR.PRODUCT_MEDIA.DELETE");
    }

    @Override
    public void deleteDraft(String fileName) {
        MediaUtils.deleteDraft(fileName);
    }

    @Override
    public void deleteDraft(Long productId, String filename) {
        MediaUtils.deleteDraftProductMedia(productId, filename);
    }

    @Override
    public void saveDraft(ProductMediaCreateDTO productMedia) {
        List<MediaDTO> draftMedia = MediaUtils.draft(productMedia.media());
        if (draftMedia.isEmpty() || draftMedia.size() != productMedia.media().length)
            throw new InvalidResourceException("ALL.MEDIA.DID.NOT.SAVED"); //TODO: message
    }

    @Override
    public void saveDraft(Long productId, ProductMediaCreateDTO request) {
        if (productRepository.exists(productId)) {
            List<MediaDTO> draftMedia = MediaUtils.draft(productId, request.media());
            if (draftMedia.isEmpty() || draftMedia.size() != request.media().length)
                throw new InvalidResourceException("ALL.MEDIA.DID.NOT.SAVED"); //TODO: message
        } else
            throw new InvalidResourceException("PRODUCT.NOT.FOUND");
    }

    @Override
    public List<MediaDTO> getAllDraft() {
        return MediaUtils.listDraft();
    }

    @Override
    public List<MediaDTO> getProductDraft(Long productId) {
        return MediaUtils.listProductDraft(productId);
    }

}