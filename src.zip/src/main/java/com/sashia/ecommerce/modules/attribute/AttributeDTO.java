package com.sashia.ecommerce.modules.attribute;

import com.sashia.ecommerce.modules.attribute.value.AttributeValueDTO;
import com.sashia.ecommerce.modules.category.dto.CategoryDTO;

import java.time.LocalDateTime;
import java.util.Set;

public record AttributeDTO(
        Long id,
        String name,
        Long categoryId,
        AttributeType type,
        Boolean isFilterable,
        String description,
        LocalDateTime createdAt,
        LocalDateTime updatedAt,
        // ******************************* Relations *******************************
        CategoryDTO category,
        Set<AttributeValueDTO> values
) {
}