package com.sashia.ecommerce.modules.payment.opg;

import com.sashia.ecommerce.modules.payment.common.PaymentDTO;

interface PaymentService {

    /* ******************************** CRUD ******************************** */

    Long create(PaymentDTO payment);

    /* ******************************** OPERATIONS ******************************** */
    //int amount, String authority, long userId
    PaymentDTO verifyPayment();

}
