package com.sashia.ecommerce.modules.attribute;

import com.sashia.ecommerce.modules.attribute.value.AttributeValueDTO;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record AttributeCreateDTO(
        @NotEmpty(message = "{attribute.name.required}") String name,
        @NotNull(message = "{category.id.required}") Long categoryId,
        @NotNull(message = "{attribute.type.required}") AttributeType type,
        @NotNull(message = "{attribute.isFilterable.required}") Boolean isFilterable,
        String description,
        List<AttributeValueDTO> values
) {
}
