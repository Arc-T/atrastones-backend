package com.sashia.ecommerce.modules.order.common;

public enum OrderStatusType {
    PENDING, PROCESSING, DELIVERED, SHIPPED, CANCELLED
}
