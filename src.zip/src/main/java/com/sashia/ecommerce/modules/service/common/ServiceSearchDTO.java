package com.sashia.ecommerce.modules.service.common;

import org.jspecify.annotations.Nullable;

public record ServiceSearchDTO(
        @Nullable String name
) {
}
