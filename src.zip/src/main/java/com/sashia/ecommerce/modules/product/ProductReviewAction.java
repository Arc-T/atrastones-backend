package com.sashia.ecommerce.modules.product;

public enum ProductReviewAction {
    LIKE, COMMENT, SAVED, SHARE, COMPARE, QUESTION
}