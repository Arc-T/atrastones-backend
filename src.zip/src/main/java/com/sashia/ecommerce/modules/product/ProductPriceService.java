package com.sashia.ecommerce.modules.product;

import com.sashia.ecommerce.modules.product.common.ProductDTO;

import java.util.List;

public interface ProductPriceService {

    List<ProductPriceDTO> applySellPrice(List<ProductDTO> products);

}
