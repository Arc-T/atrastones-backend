package com.sashia.ecommerce.modules.product.media;

import org.springframework.web.multipart.MultipartFile;

public record ProductMediaUpdateDTO(MultipartFile[] media) {
}
