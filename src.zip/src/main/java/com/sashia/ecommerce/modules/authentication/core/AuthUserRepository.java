package com.sashia.ecommerce.modules.authentication.core;

import java.util.Optional;

public interface AuthUserRepository {

    Optional<AuthUser> findByPhone(String phone);

}