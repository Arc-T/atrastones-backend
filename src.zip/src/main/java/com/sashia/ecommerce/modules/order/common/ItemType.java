package com.sashia.ecommerce.modules.order.common;

public enum ItemType {
    PRODUCT, SERVICE
}
