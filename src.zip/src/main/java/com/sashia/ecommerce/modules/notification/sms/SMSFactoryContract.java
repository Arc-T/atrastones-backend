package com.sashia.ecommerce.modules.notification.sms;

import com.sashia.ecommerce.modules.notification.sms.common.SMSProvider;

public interface SMSFactoryContract {

    SMSContract getService(SMSProvider provider);

}
