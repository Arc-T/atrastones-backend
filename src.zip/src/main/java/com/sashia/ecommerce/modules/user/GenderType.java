package com.sashia.ecommerce.modules.user;

public enum GenderType {
    MALE, FEMALE
}
