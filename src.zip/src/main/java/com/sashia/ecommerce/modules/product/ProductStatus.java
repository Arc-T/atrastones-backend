package com.sashia.ecommerce.modules.product;

public enum ProductStatus {
    ACTIVE, INACTIVE, OUT_OF_STOCK
}
