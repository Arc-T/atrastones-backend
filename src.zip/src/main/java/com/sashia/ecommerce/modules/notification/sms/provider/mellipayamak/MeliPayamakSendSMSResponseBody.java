package com.sashia.ecommerce.modules.notification.sms.provider.mellipayamak;

public record MeliPayamakSendSMSResponseBody(
        String Value,
        Long RetStatus,
        String StrRetStatus
) {
}
