package com.sashia.ecommerce.modules.attribute;

import com.sashia.ecommerce.modules.attribute.value.AttributeValueMapper;
import com.sashia.ecommerce.modules.category.Category;
import com.sashia.ecommerce.modules.category.CategoryMapper;

import java.util.stream.Collectors;

public final class AttributeMapper {

    private AttributeMapper() {
    }

    public static AttributeDTO toDTO(Attribute attribute) {
        return new AttributeDTO(
                attribute.getId(),
                attribute.getName(),
                attribute.getCategoryId(),
                attribute.getType(),
                attribute.getFilterable(),
                attribute.getDescription(),
                attribute.getCreatedAt(),
                attribute.getUpdatedAt(),
                CategoryMapper.toDTO(attribute.getCategory()),
                attribute.getAttributeValues()
                        .stream().map(AttributeValueMapper::toDTO).collect(Collectors.toUnmodifiableSet())
        );
    }

    public static Attribute toEntity(AttributeCreateDTO dto, Category category) {
        Attribute attribute = new Attribute();
        attribute.setName(dto.name());
        attribute.setCategory(category);
        attribute.setFilterable(dto.isFilterable());
        attribute.setType(dto.type());
        attribute.setDescription(dto.description());
        return attribute;
    }

    public static void update(Attribute attribute, AttributeUpdateDTO dto, Category category) {
        attribute.setName(dto.name());
        attribute.setCategory(category);
        attribute.setFilterable(dto.isFilterable());
        attribute.setType(attribute.getType());
        attribute.setDescription(dto.description());
    }


}