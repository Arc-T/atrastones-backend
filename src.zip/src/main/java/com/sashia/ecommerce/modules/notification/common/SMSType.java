package com.sashia.ecommerce.modules.notification.common;

public enum SMSType {
    OTP
}