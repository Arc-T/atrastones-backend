package com.sashia.ecommerce.modules.shop;

public enum ShopStatus {
    ACTIVE, INACTIVE, PENDING
}
