package com.sashia.ecommerce.modules.notification.sms.common;

public record SMSWrapperResponseDTO(
        Long statusId,
        String result,
        String description
) {
}