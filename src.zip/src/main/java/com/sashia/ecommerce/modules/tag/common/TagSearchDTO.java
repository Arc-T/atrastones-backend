package com.sashia.ecommerce.modules.tag.common;

import org.jspecify.annotations.Nullable;

public record TagSearchDTO(
        @Nullable String name
) {
}
