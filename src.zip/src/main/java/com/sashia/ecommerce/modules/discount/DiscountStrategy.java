package com.sashia.ecommerce.modules.discount;

import java.math.BigDecimal;

@FunctionalInterface
public interface DiscountStrategy {

    BigDecimal calculate(BigDecimal price);

}