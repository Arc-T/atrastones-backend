package com.sashia.ecommerce.modules.tag.common;

import jakarta.validation.constraints.NotBlank;

public record TagCreateDTO(
        @NotBlank(message = "{tag.name.required}")
        String name
) {
}
