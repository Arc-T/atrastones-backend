package com.sashia.ecommerce.modules.notification.sms.common;

public enum SMSProvider {
    MELLI_PAYAMAK
}
