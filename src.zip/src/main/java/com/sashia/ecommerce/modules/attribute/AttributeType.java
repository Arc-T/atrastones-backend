package com.sashia.ecommerce.modules.attribute;

public enum AttributeType {
    TEXT, NUMBER, SELECT, MULTISELECT, DECIMAL
}
