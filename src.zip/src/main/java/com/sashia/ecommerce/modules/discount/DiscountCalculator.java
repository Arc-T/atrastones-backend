package com.sashia.ecommerce.modules.discount;

import java.math.BigDecimal;

public interface DiscountCalculator {

    DiscountStrategy noDiscount();

    DiscountStrategy fixedDiscount(BigDecimal amount);

    DiscountStrategy percentDiscount(BigDecimal percentage);

}
