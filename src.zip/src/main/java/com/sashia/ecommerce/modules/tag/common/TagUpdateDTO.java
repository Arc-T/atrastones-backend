package com.sashia.ecommerce.modules.tag.common;

import jakarta.validation.constraints.NotBlank;

public record TagUpdateDTO(
        @NotBlank(message = "{tag.name.required}")
        String name
) {
}
