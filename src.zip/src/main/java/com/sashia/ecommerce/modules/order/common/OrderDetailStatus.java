package com.sashia.ecommerce.modules.order.common;

public enum OrderDetailStatus {
    PENDING, COMPLETED, CANCELLED, REJECTED
}
