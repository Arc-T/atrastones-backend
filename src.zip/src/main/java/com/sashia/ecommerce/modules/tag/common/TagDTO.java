package com.sashia.ecommerce.modules.tag.common;

import com.sashia.ecommerce.modules.tag.Tag;

public record TagDTO(
        Long id,
        String name
) {
    // *********************** DTO ***********************
    public static TagDTO toDTO(Tag tag) {
        return new TagDTO(
                tag.id(),
                tag.name()
        );
    }

}
