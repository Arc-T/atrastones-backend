package com.sashia.ecommerce.modules.authentication.common;

public enum LoginType {
    SMS, PASSWORD, EMAIL,
}
