package com.sashia.ecommerce.modules.authentication.core;

import com.sashia.ecommerce.modules.authentication.common.AuthenticationDTO;
import com.sashia.ecommerce.modules.authentication.common.LoginDTO;

public interface AuthenticationService {

    /* =============================== OPERATIONS =============================== */

    AuthenticationDTO attemptWithOTP(String phone, Integer otpCode);

    AuthenticationDTO authenticateAdmin(LoginDTO credentials);

    AuthenticationDTO authenticateCustomer(AuthenticationDTO authentication);

}
