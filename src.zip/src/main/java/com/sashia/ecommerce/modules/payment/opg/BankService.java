package com.sashia.ecommerce.modules.payment.opg;

public interface BankService {

    void initiatePayment();

    boolean checkPayment();

}
