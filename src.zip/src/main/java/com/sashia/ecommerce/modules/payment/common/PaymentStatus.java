package com.sashia.ecommerce.modules.payment.common;

public enum PaymentStatus {
    PENDING, PAID, FAILED, REFUNDED
}
