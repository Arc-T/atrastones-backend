package com.sashia.ecommerce.modules.attribute.value;

import java.time.LocalDateTime;

public record AttributeValueDTO(
        Long id,
        String value,
        LocalDateTime createdAt
) {

    public AttributeValueDTO(String value) {
        this(null, value, null);
    }

}
