package com.sashia.ecommerce.modules.payment.opg;

public abstract class Bank implements BankService {

    protected void logInsertedPayment() {
    }

}
