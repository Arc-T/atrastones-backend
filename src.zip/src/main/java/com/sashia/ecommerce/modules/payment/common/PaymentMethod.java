package com.sashia.ecommerce.modules.payment.common;

public enum PaymentMethod {
    CARD, WEB, APP, CASH, GATEWAY
}
