package com.sashia.ecommerce.modules.order.common;

public record OrderSearchDTO() {
}
