package com.sashia.ecommerce;

import com.sashia.ecommerce.modules.attribute.AttributeService;
import com.sashia.ecommerce.modules.attribute.AttributeType;
import com.sashia.ecommerce.modules.attribute.AttributeCreateDTO;
import com.sashia.ecommerce.modules.attribute.AttributeDTO;
import com.sashia.ecommerce.modules.attribute.AttributeUpdateDTO;
import com.sashia.ecommerce.modules.attribute.value.AttributeValueDTO;
import com.sashia.ecommerce.internal.BaseControllerTest;
import com.sashia.ecommerce.internal.Language;
import com.sashia.ecommerce.internal.TestWithLocale;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.ResultActions;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@DisplayName("Attribute Controller Tests")
class AttributeControllerTest extends BaseControllerTest {

    private static final String BASE_URL = "/attributes";
    private static final long EXISTING_ATTRIBUTE_ID = 1L;
    private static final long NON_EXISTENT_ATTRIBUTE_ID = 0L;
    private static final long INVALID_CATEGORY_ID = 0L;
    private static final long VALID_CATEGORY_ID = 1L;
    private static final long NEW_ATTRIBUTE_ID = 10L;

    @Autowired
    private AttributeService attributeService;

    @Nested
    @DisplayName("GET " + BASE_URL)
    class GetAllAttributes {

        @Test
        @WithMockUser(authorities = "READ_ALL_ATTRIBUTES")
        @DisplayName("Should return all attributes with status 200")
        void shouldReturnAllAttributes() throws Exception {
            mockMvc().perform(get(BASE_URL)
                            .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.content").isArray())
                    .andExpect(jsonPath("$.content.length()").value(2))
                    .andExpect(jsonPath("$.page.totalElements").value(2));
        }

        @Test
        @WithMockUser(authorities = "READ_ALL_ATTRIBUTES")
        @DisplayName("Should return one filtered attributes when search param matches")
        void shouldReturnFilteredAttributes_whenSearchParamMatchesOne() throws Exception {
            String searchTerm = "بند";

            mockMvc().perform(get(BASE_URL)
                            .param("name", searchTerm)
                            .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.content.length()").value(1));

        }

        @Test
        @WithMockUser(authorities = "READ_ALL_ATTRIBUTES")
        @DisplayName("Should return all filtered attributes when search param matches")
        void shouldReturnFilteredAttributes_whenSearchParamMatchesWithMoreThanOne() throws Exception {
            String searchTerm = "جنس";

            mockMvc().perform(get(BASE_URL)
                            .param("name", searchTerm)
                            .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.content.length()").value(2));
        }

        @Test
        @WithMockUser(authorities = "READ_ALL_ATTRIBUTES")
        @DisplayName("Should return empty page when search param doesn't match")
        void shouldReturnEmptyPage_whenSearchParamDoesNotMatch() throws Exception {
            String searchTerm = "non-existent-term";

            mockMvc().perform(get(BASE_URL)
                            .param("name", searchTerm)
                            .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.content").isEmpty())
                    .andExpect(jsonPath("$.page.totalElements").value(0));
        }

        @Test
        @WithMockUser
        @DisplayName("Should return 403 when user lacks authority")
        void shouldReturnForbidden_whenUserLacksAuthority() throws Exception {
            mockMvc().perform(get(BASE_URL)
                            .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isForbidden());
        }

        @Test
        @WithMockUser(authorities = "READ_ALL_ATTRIBUTES")
        @DisplayName("Should support pagination parameters")
        void shouldSupportPagination() throws Exception {
            mockMvc().perform(get(BASE_URL)
                            .param("page", "0")
                            .param("size", "10")
                            .param("sort", "name,asc")
                            .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.page.number").value(0))
                    .andExpect(jsonPath("$.page.size").value(10));
        }

    }

    @Nested
    @DisplayName("GET " + BASE_URL + "/types")
    class GetAllAttributeTypes {

        @Test
        @WithMockUser(authorities = "READ_ALL_ATTRIBUTE_TYPES")
        @DisplayName("Should return all filtered attributes when search param matches")
        void shouldReturnAlAttributeTypes() throws Exception {
            mockMvc().perform(get(BASE_URL + "/types")
                            .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk())
                    .andDo(print());
        }

    }

    @Nested
    @DisplayName("POST " + BASE_URL)
    class CreateAttribute {

        @Test
        @WithMockUser(authorities = "CREATE_ATTRIBUTE")
        @DirtiesContext
        @DisplayName("Should create attribute and return 201 with location header")
        void shouldCreateAttribute() throws Exception {
            AttributeCreateDTO request = validCreateRequest();

            mockMvc().perform(post(BASE_URL)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper().writeValueAsString(request)))
                    .andExpect(status().isCreated())
                    .andExpect(header().string(HttpHeaders.LOCATION, BASE_URL + "/" + NEW_ATTRIBUTE_ID));

            AttributeDTO created = attributeService.read(NEW_ATTRIBUTE_ID)
                    .orElseThrow();

            assertAll(
                    () -> assertThat(created.name()).isEqualTo(request.name()),
                    () -> assertThat(created.categoryId()).isEqualTo(request.categoryId()),
                    () -> assertThat(created.type()).isEqualTo(request.type()),
                    () -> assertThat(created.isFilterable()).isEqualTo(request.isFilterable()),
                    () -> assertThat(created.values().size()).isEqualTo(request.values().size())
            );
        }

        @TestWithLocale
        @WithMockUser(authorities = "CREATE_ATTRIBUTE")
        @DisplayName("Should return 400 when request validation fails")
        void shouldReturnBadRequest_whenValidationFails(Language language) throws Exception {
            mockMvc().perform(post(BASE_URL)
                            .locale(language.getLocale())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper().writeValueAsString(invalidCreateRequest())))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.message")
                            .value(message("invalid.method.params", language.getLocale())))
                    .andExpect(jsonPath("$.details.fieldErrors.name")
                            .value(message("attribute.name.required", language.getLocale())))
                    .andExpect(jsonPath("$.details.fieldErrors.type")
                            .value(message("attribute.type.required", language.getLocale())))
                    .andExpect(jsonPath("$.details.fieldErrors.isFilterable")
                            .value(message("attribute.isFilterable.required", language.getLocale())))
                    .andExpect(jsonPath("$.details.fieldErrors.categoryId")
                            .value(message("category.id.required", language.getLocale())));
        }

        @TestWithLocale
        @WithMockUser(authorities = "CREATE_ATTRIBUTE")
        @DisplayName("Should return 422 when category does not exist")
        void shouldReturnUnprocessableEntity_whenCategoryDoesNotExist(Language language) throws Exception {
            mockMvc().perform(post(BASE_URL)
                            .locale(language.getLocale())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper().writeValueAsString(createRequest(INVALID_CATEGORY_ID))))
                    .andExpect(status().isUnprocessableContent())
                    .andExpect(jsonPath("$.message")
                            .value(message("category.not.found", language.getLocale())));
        }

        @Test
        @WithMockUser
        @DisplayName("Should return 403 when user lacks authority")
        void shouldReturnForbidden_whenUserLacksAuthority() throws Exception {
            mockMvc().perform(post(BASE_URL)
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper().writeValueAsString(validCreateRequest())))
                    .andExpect(status().isForbidden());
        }

        private AttributeCreateDTO validCreateRequest() {
            return createRequest(VALID_CATEGORY_ID);
        }

        private AttributeCreateDTO createRequest(Long categoryId) {
            return new AttributeCreateDTO(
                    "size",
                    categoryId,
                    AttributeType.SELECT,
                    false,
                    null,
                    List.of(
                            new AttributeValueDTO("2X"),
                            new AttributeValueDTO("3X"),
                            new AttributeValueDTO("LG"),
                            new AttributeValueDTO("MD"),
                            new AttributeValueDTO("SM")
                    )
            );
        }

        private AttributeCreateDTO invalidCreateRequest() {
            return new AttributeCreateDTO(
                    null,
                    null,
                    null,
                    null,
                    null,
                    null
            );
        }
    }

    @Nested
    @DisplayName("PUT " + BASE_URL + "/{id}")
    class UpdateAttribute {

        @Test
        @WithMockUser(authorities = "UPDATE_ATTRIBUTE")
        @DirtiesContext
        @DisplayName("Should update attribute and return 204")
        void shouldUpdateAttribute() throws Exception {
            // Given
            AttributeUpdateDTO request = new AttributeUpdateDTO(
                    "size", 1L, "TEXT", true, null, null
            );

            // When
            ResultActions result = mockMvc().perform(put(BASE_URL + "/{id}", EXISTING_ATTRIBUTE_ID)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper().writeValueAsString(request)));

            // Then
            result.andExpect(status().isNoContent());

            // Verify in database
            AttributeDTO updatedAttribute = assertDoesNotThrow(() -> attributeService.read(EXISTING_ATTRIBUTE_ID).get());

            assertAll("Verify updated attribute properties",
                    () -> assertThat(updatedAttribute.name()).isEqualTo(request.name()),
                    () -> assertThat(updatedAttribute.categoryId()).isEqualTo(request.categoryId()),
                    () -> assertThat(updatedAttribute.type()).isEqualTo(request.type()),
                    () -> assertThat(updatedAttribute.isFilterable()).isEqualTo(request.isFilterable())
            );
        }

        @Test
        @WithMockUser(authorities = "UPDATE_ATTRIBUTE")
        @DisplayName("Should return 422 when attribute ID doesn't exist")
        void shouldReturnUnprocessableContent_whenAttributeNotFound() throws Exception {
            // Given
            AttributeUpdateDTO request = new AttributeUpdateDTO(
                    "size", 1L, "TEXT", true, null, null
            );

            // When
            ResultActions result = mockMvc().perform(put(BASE_URL + "/{id}", NON_EXISTENT_ATTRIBUTE_ID)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper().writeValueAsString(request)));

            // Then
            result.andExpect(status().isUnprocessableContent());
        }

        @TestWithLocale
        @WithMockUser(authorities = "UPDATE_ATTRIBUTE")
        @DisplayName("Should return 400 when request validation fails")
        void shouldReturnBadRequest_whenValidationFails(Language language) throws Exception {
            // Given
            AttributeUpdateDTO request = new AttributeUpdateDTO(null, null, null, null,
                    null, null);

            // When
            ResultActions result = mockMvc().perform(put(BASE_URL + "/{id}", EXISTING_ATTRIBUTE_ID)
                    .locale(language.getLocale())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper().writeValueAsString(request)));

            // Then
            result.andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.message").value(message("invalid.method.params", language.getLocale())));
        }

        @TestWithLocale
        @WithMockUser(authorities = "UPDATE_ATTRIBUTE")
        @DisplayName("Should return 422 when category ID doesn't exist")
        void shouldReturnUnprocessableContent_whenCategoryNotFound(Language language) throws Exception {
            // Given
            AttributeUpdateDTO request = new AttributeUpdateDTO(
                    "test", INVALID_CATEGORY_ID, "TEXT", false, null, null
            );

            // When
            ResultActions result = mockMvc().perform(put(BASE_URL + "/{id}", EXISTING_ATTRIBUTE_ID)
                    .locale(language.getLocale())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper().writeValueAsString(request)));

            // Then
            result.andExpect(status().isUnprocessableContent())
                    .andExpect(jsonPath("$.message").value(message("attribute.category.not.found", language.getLocale())));
        }

    }

    @Nested
    @DisplayName("DELETE " + BASE_URL + "/{id}")
    class DeleteAttribute {

        @Test
        @Disabled("TODO: Implement delete endpoint and tests")
        @DisplayName("Should delete attribute and return 204")
        void shouldDeleteAttribute() {
            // TODO: Implement delete test
        }

    }

}