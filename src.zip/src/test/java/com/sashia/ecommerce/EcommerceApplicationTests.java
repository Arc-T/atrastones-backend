package com.sashia.ecommerce;

import com.sashia.ecommerce.modules.EcommerceApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.modulith.core.ApplicationModules;

@SpringBootTest
class EcommerceApplicationTests {

    @Test
    public void testModules() throws Exception {
        ApplicationModules.of(EcommerceApplication.class).verify();
    }

}
